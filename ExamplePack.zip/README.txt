You can feel free to modify and distribute this resource pack as you wish, or include parts of it in your own resource packs, but you must include the copyright notice found in assets/minecraft/textures/font. The copyright notice applies only to the ten fontsheets included in that folder.

Feel free to delete this README.txt, and thank you for downloading!

~WolfieMario

This is the small version of the pack (256x256px font files) which is necessary due to a limitation that has been in Minecraft since 1.13 where it doesn't use larger font files. (See https://bugs.mojang.com/browse/MC-133372)

For the original 512x512px big pack take a look here: https://cdn.moep.tv/files/Custom_Icons_Resource_Pack_big.zip

~Phoenix616